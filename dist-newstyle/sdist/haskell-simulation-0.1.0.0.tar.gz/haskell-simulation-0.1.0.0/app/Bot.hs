module Bot  where 
import Environment
import Element
import Utils
import Data.List
-- move:: Environment -> Bot -> Environment
-- move Environment bot = do
--     let empty = head (empties Environment) in
--         Environment {bots = (bots Environment)++[Bot (fst empty, snd empty)]}

-- moveAll:: Environment -> Environment
-- moveAll Environment =
--     foldl move Environment (bots Environment)



sortTuplesDistances (a1, b1) (a2, b2) = compare b1 b2

nearestKid:: Environment -> Position -> Element
nearestKid env initialPos = let elementWithDistances = map (\element -> (element, manhattanDistance initialPos (pos element)) ) (kids env)
    in sortOn snd elementWithDistances
    |> head -- devuelve el kid
    |> fst

tryGoToPosition:: Environment -> Element -> Position -> Environment
tryGoToPosition environment bot position = let element = getElementAtPosition environment position in
    case element of 
        Nothing -> environment
        Just element ->  
            case (bot , environment , element) of
                (_,_,EmptyCell(_,_)) -> environment {
                        empties = removeItem element (empties environment) ++ [ EmptyCell (pos bot)],
                        bots = (removeItem bot (bots environment)) ++ [ Bot (pos element)]
                    }
                (_,_,Kid(_,_)) -> environment {
                        empties = removeItem element (empties environment) ++ [ EmptyCell (pos bot) ],
                        kids = removeItem element (kids environment),
                        bots = (removeItem bot (bots environment)),
                        botsWithKid = botsWithKid environment ++ [BotWithKid(pos element)]
                    }
                (_,_,Dirt(_,_)) -> environment {
                        empties = removeItem element (empties environment) ++ [ EmptyCell (pos bot) ],
                        dirts = removeItem element (dirts environment),
                        bots = (removeItem bot (bots environment)),
                        botsWithKid = botsWithKid environment ++ [ BotWithKid( pos element ) ]
                    }
                (_,_,_) -> environment


move:: Environment -> Element -> Environment
move env bot = let kidToPick = nearestKid env (pos bot) in 
    let bestPathToKid = dirtiestShortestFreePath env (pos bot) (pos kidToPick)
    in case bestPathToKid of
        [] -> env --Goto to the nearest dirty and clean
        value -> tryGoToPosition env bot (head value)
        




-------------------------------------------------Smart stuff------------------------------------------------------------

--Similar to isDirty, but returns an int
isDirtInt:: Maybe Element -> Int
isDirtInt element = case element of 
            Nothing -> 0
            Just element ->
                case (element) of
                    (Dirt (_,_)) -> 1 
                    _ -> 0

-- Gets the dirtiness(amount of dirty elements) of a given path
dirtyness:: Environment -> [Position] -> Int
-- dirtyness env path = sum (map (isDirtInt (.) getElementAtPosition) path)
--TODO: check if this works, porke ta mas chula
dirtyness env path = sum (map (\a -> isDirtInt (getElementAtPosition env a)) path)

------BFS returning all shortest paths
bfs:: [(Int,Int)] -> (Int,Int) -> (Int, Int) -> [[(Int,Int)]]
bfs matrix initialPos finalPos = [[initialPos, finalPos]]

-- Transforms the input into Tuples of (Int,Int). Calls bfs
allShortestFreePath:: Environment -> Position -> Position -> [[Position]]
allShortestFreePath env initial final =
    let positions = (empties env ++ dirts env) |> map (\a -> pos a)
    in bfs positions initial final

-- Get allShortestFreePath. Map it into a Tuple of ([Position],Int) where the snd is the dirtiness of the path.
-- Return the dirties path
dirtiestShortestFreePath:: Environment -> Position -> Position -> [Position]
dirtiestShortestFreePath env initial final = allShortestFreePath env initial final 
    |> map (\path -> (path, dirtyness env path))
    -- sort by the most dirties path and return the first
    |> sortOn snd
    |> head 
    |> fst
    