module EmptyCell where 

-- import Element

