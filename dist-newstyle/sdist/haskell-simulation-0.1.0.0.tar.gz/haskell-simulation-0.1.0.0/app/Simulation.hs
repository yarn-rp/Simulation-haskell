module Simulation where

import Environment
import Element
import Kid


environment =  initEnvironment 5 5
environmentChanged = Kid.moveAll environment