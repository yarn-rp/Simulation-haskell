module Main where

import Simulation
import Element
import Environment
main :: IO ()
main = do 
    print environment
    print environmentChanged
    -- print (directionToMove (Kid(1,1)) ((2,1)) )
    -- print (getElementAtPosition environmentChanged (1,1))



-- Environment = createEnvironment 2 2
-- print Environment = putStrLn (show Environment)